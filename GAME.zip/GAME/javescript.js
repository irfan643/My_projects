document.addEventListener('DOMContentLoaded', () => {
    const numberContainer = document.getElementById('numberContainer');
    const startButton = document.getElementById('startButton');
    let selectedBlocks = [];

    function createShuffledNumbers() {
        const numbers = Array.from({ length: 10 }, (_, i) => i + 1).flatMap(n => [n, n]);
        for (let i = numbers.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
        }
        return numbers;
    }

    function startGame() {
        numberContainer.innerHTML = '';  // Clear previous blocks
        selectedBlocks = [];
        const numbers = createShuffledNumbers();
        numbers.forEach(number => {
            const numberBlock = document.createElement('div');
            numberBlock.classList.add('number-block');
            numberBlock.textContent = number;
            numberBlock.addEventListener('click', () => selectBlock(numberBlock));
            numberContainer.appendChild(numberBlock);
        });
    }

    function selectBlock(block) {
        if (block.classList.contains('selected') || selectedBlocks.length === 2) {
            return;
        }

        block.classList.add('selected');
        block.style.color = 'white';
        selectedBlocks.push(block);

        if (selectedBlocks.length === 2) {
            setTimeout(checkMatch, 1000);
        }
    }

    function checkMatch() {
        const [block1, block2] = selectedBlocks;
        if (block1.textContent === block2.textContent) {
            block1.remove();
            block2.remove();
        } else {
            block1.classList.remove('selected');
            block1.style.color = 'transparent';
            block2.classList.remove('selected');
            block2.style.color = 'transparent';
        }
        selectedBlocks = [];
        checkGameOver();
    }

    function checkGameOver() {
        if (numberContainer.children.length === 0) {
            alert('Congratulations! You matched all the numbers!');
        }
    }

    startButton.addEventListener('click', startGame);
});
