const pokiAPI = "https://pokeapi.co/api/v2/pokemon/";
const game = document.getElementById('game')
let isPaused = false;
let firstpick;
const loadpoki = async () => {
    const randomids = new Set();
    while (randomids.size < 8) {
        const random_number = Math.ceil(Math.random() * 150);
        randomids.add(random_number);
    }
    console.log(randomids)
    // Fetching data for 8 random Pokémon
    const pokepromise = [...randomids].map(id => fetch(pokiAPI + id));
    const response = await Promise.all(pokepromise);
            
   
   
    return await Promise.all(response.map(res => res.json()));


    
}
   

const dispalypokemn = (pokemon) => {
    console.log(pokemon);
    pokemon.sort(_ => Math.random() - 0.5);
    pokemon.map(p => console.log(p.name))
    pokemon.map(p => console.log(p.sprites.front_default))


    function getRandomRGB() {
        const r = Math.floor(Math.random() * 256) + 128;
        const g = Math.floor(Math.random() * 256) + 128;
        const b = Math.floor(Math.random() * 256) + 128;
        return `rgb(${r}, ${g}, ${b})`;
    }

    const pokihtml = pokemon.map(pokemon => {


        return `
          <div class="card"   onclick="clickcard(event)" style="background-color: ${getRandomRGB()}"  
             data-pokemon ="${pokemon.name}">
              <div class="front"></div>
              <div class="back rotated">
                   <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}"  >
                    <div id ="text">${pokemon.name}
                     </div>
                 </div>   
                    
             </div>          
        `;
    }
    ).join('');
    game.innerHTML = pokihtml;

};
const clickcard = (event) => {
    const pokemon_data = event.currentTarget;
    const [front, back] = get_front_back(pokemon_data);

    // If card is already rotated or the game is paused,return
    if (front.classList.contains('rotated') || isPaused) return;

    // Flip the current card
    front.classList.toggle('rotated');
    back.classList.toggle('rotated');

    if (!firstpick) {
        // This is the first card picked
        firstpick = pokemon_data;
        isPaused = false;
    } else {
        // This is the second card picked
        const first_cardname = firstpick.dataset.pokemon;
        const second_cardname = pokemon_data.dataset.pokemon;

        // Pause the game while we check and possibly flip cards back
        isPaused = true;

        if (first_cardname === second_cardname) {
            // If the names match, keep both cards flipped
            console.log("Cards match! They stay flipped.");
            firstpick = null;
            isPaused = false; // Unpause the game
        } else {
            // If names don't match, flip both cards back after a delay
            const [first_front, first_back] = get_front_back(firstpick);
            setTimeout(() => {
                // Flip both cards back
                first_front.classList.toggle('rotated');
                first_back.classList.toggle('rotated');
                front.classList.toggle('rotated');
                back.classList.toggle('rotated');

                // Reset firstpick and unpause the game
                firstpick = null;
                isPaused = false;
            }, 500); // 500ms delay before flipping back
        }
    }
};

const rotate_element = (element) => {
    if (typeof element != 'object' || element.length) return;
    element.forEach(element => element.classList.toggle('rotated'));
}

const get_front_back = (card) => {
    const front = card.querySelector(".front");
    const back = card.querySelector(".back"); // This is the correct selection for the back
    return [front, back];
}
const reset = async () => {
    const pokemon = await loadpoki();
    dispalypokemn([...pokemon, ...pokemon])
}
// Call the function to test it
reset();

